from pathlib import Path
import sys
import joblib
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report,
    confusion_matrix,
    roc_auc_score
)


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATA_PATH = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "smart_logistics_dataset.csv"
)

MODEL_DIR = PROJECT_ROOT / "models"

MODEL_DIR.mkdir(
    exist_ok=True
)


# ============================================================
# IMPORT PREPROCESSING
# ============================================================

sys.path.append(
    str(PROJECT_ROOT)
)

from src.preprocessing import (
    load_data,
    clean_data,
    create_features,
    get_model_data
)


# ============================================================
# LOAD DATA
# ============================================================

print("\n" + "=" * 70)
print("AI SHIPMENT DELAY PREDICTOR")
print("=" * 70)

df = load_data(DATA_PATH)


# ============================================================
# CLEAN DATA
# ============================================================

df = clean_data(df)

print("\nAfter cleaning:")
print(df.shape)


# ============================================================
# FEATURE ENGINEERING
# ============================================================

df = create_features(df)

print("\nAfter feature engineering:")
print(df.shape)


# ============================================================
# FEATURES / TARGET
# ============================================================

X, y = get_model_data(df)

print("\nFeatures:")
print(X.columns.tolist())

print("\nTarget distribution:")
print(y.value_counts())


# ============================================================
# IDENTIFY DATA TYPES
# ============================================================

numeric_features = X.select_dtypes(
    include=["int64", "float64", "int32", "float32"]
).columns.tolist()

categorical_features = X.select_dtypes(
    include=["object", "category", "bool"]
).columns.tolist()


print("\nNumeric features:")
print(numeric_features)

print("\nCategorical features:")
print(categorical_features)


# ============================================================
# NUMERIC PIPELINE
# ============================================================

numeric_pipeline = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(strategy="median")
        ),
        (
            "scaler",
            StandardScaler()
        )
    ]
)


# ============================================================
# CATEGORICAL PIPELINE
# ============================================================

categorical_pipeline = Pipeline(
    steps=[
        (
            "imputer",
            SimpleImputer(
                strategy="most_frequent"
            )
        ),
        (
            "encoder",
            OneHotEncoder(
                handle_unknown="ignore"
            )
        )
    ]
)


# ============================================================
# PREPROCESSOR
# ============================================================

preprocessor = ColumnTransformer(
    transformers=[
        (
            "numeric",
            numeric_pipeline,
            numeric_features
        ),
        (
            "categorical",
            categorical_pipeline,
            categorical_features
        )
    ]
)


# ============================================================
# TRAIN / TEST SPLIT
# ============================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)


print("\nTraining samples:", len(X_train))
print("Testing samples :", len(X_test))


# ============================================================
# MODEL 1 — LOGISTIC REGRESSION
# ============================================================

logistic_model = Pipeline(
    steps=[
        (
            "preprocessor",
            preprocessor
        ),
        (
            "model",
            LogisticRegression(
                max_iter=2000
            )
        )
    ]
)


print("\nTraining Logistic Regression...")

logistic_model.fit(
    X_train,
    y_train
)

logistic_predictions = (
    logistic_model.predict(X_test)
)

logistic_probabilities = (
    logistic_model.predict_proba(X_test)[:, 1]
)


# ============================================================
# MODEL 2 — RANDOM FOREST
# ============================================================

random_forest_model = Pipeline(
    steps=[
        (
            "preprocessor",
            preprocessor
        ),
        (
            "model",
            RandomForestClassifier(
                n_estimators=300,
                max_depth=12,
                min_samples_split=5,
                random_state=42,
                class_weight="balanced"
            )
        )
    ]
)


print("\nTraining Random Forest...")

random_forest_model.fit(
    X_train,
    y_train
)

rf_predictions = (
    random_forest_model.predict(X_test)
)

rf_probabilities = (
    random_forest_model.predict_proba(X_test)[:, 1]
)


# ============================================================
# EVALUATION FUNCTION
# ============================================================

def evaluate_model(
    model_name,
    y_true,
    predictions,
    probabilities
):

    accuracy = accuracy_score(
        y_true,
        predictions
    )

    precision = precision_score(
        y_true,
        predictions,
        zero_division=0
    )

    recall = recall_score(
        y_true,
        predictions,
        zero_division=0
    )

    f1 = f1_score(
        y_true,
        predictions,
        zero_division=0
    )

    auc = roc_auc_score(
        y_true,
        probabilities
    )

    print("\n" + "-" * 70)
    print(model_name)
    print("-" * 70)

    print(f"Accuracy  : {accuracy:.4f}")
    print(f"Precision : {precision:.4f}")
    print(f"Recall    : {recall:.4f}")
    print(f"F1 Score  : {f1:.4f}")
    print(f"ROC-AUC   : {auc:.4f}")

    print("\nClassification Report:")

    print(
        classification_report(
            y_true,
            predictions,
            zero_division=0
        )
    )

    print("Confusion Matrix:")

    print(
        confusion_matrix(
            y_true,
            predictions
        )
    )

    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "roc_auc": auc
    }


# ============================================================
# EVALUATE MODELS
# ============================================================

logistic_metrics = evaluate_model(
    "LOGISTIC REGRESSION",
    y_test,
    logistic_predictions,
    logistic_probabilities
)


rf_metrics = evaluate_model(
    "RANDOM FOREST",
    y_test,
    rf_predictions,
    rf_probabilities
)


# ============================================================
# SELECT MODEL BASED ON F1
# ============================================================

if rf_metrics["f1"] >= logistic_metrics["f1"]:

    best_model = random_forest_model

    best_model_name = "Random Forest"

    best_metrics = rf_metrics

else:

    best_model = logistic_model

    best_model_name = "Logistic Regression"

    best_metrics = logistic_metrics


# ============================================================
# SAVE MODEL
# ============================================================

model_path = (
    MODEL_DIR
    / "delay_predictor.pkl"
)

joblib.dump(
    best_model,
    model_path
)


# ============================================================
# SAVE MODEL INFORMATION
# ============================================================

model_info = {
    "model_name": best_model_name,
    "features": X.columns.tolist(),
    "metrics": best_metrics
}

joblib.dump(
    model_info,
    MODEL_DIR / "model_info.pkl"
)


# ============================================================
# FINAL OUTPUT
# ============================================================

print("\n" + "=" * 70)
print("MODEL TRAINING COMPLETED")
print("=" * 70)

print(f"\nBest model: {best_model_name}")

print(
    f"F1 Score: "
    f"{best_metrics['f1']:.4f}"
)

print(
    f"Accuracy: "
    f"{best_metrics['accuracy']:.4f}"
)

print(
    f"\nModel saved to:\n"
    f"{model_path}"
)

print("\n" + "=" * 70)