import pandas as pd
import numpy as np


TARGET_COLUMN = "Logistics_Delay"


def load_data(file_path):
    """
    Load the raw logistics dataset.
    """
    df = pd.read_csv(file_path)

    print(f"Dataset loaded successfully: {df.shape}")

    return df


def clean_data(df):
    """
    Clean and prepare the raw dataset.
    """

    df = df.copy()

    # ---------------------------------------------------------
    # Remove duplicate records
    # ---------------------------------------------------------

    df = df.drop_duplicates()

    # ---------------------------------------------------------
    # Convert timestamp
    # ---------------------------------------------------------

    if "Timestamp" in df.columns:

        df["Timestamp"] = pd.to_datetime(
            df["Timestamp"],
            errors="coerce"
        )

        # Time-based features
        df["Year"] = df["Timestamp"].dt.year
        df["Month"] = df["Timestamp"].dt.month
        df["Day"] = df["Timestamp"].dt.day
        df["Hour"] = df["Timestamp"].dt.hour
        df["Day_of_Week"] = df["Timestamp"].dt.dayofweek

        # Weekend flag
        df["Is_Weekend"] = (
            df["Day_of_Week"] >= 5
        ).astype(int)

        # Remove original timestamp
        df = df.drop(columns=["Timestamp"])

    # ---------------------------------------------------------
    # Clean string columns
    # ---------------------------------------------------------

    for column in df.select_dtypes(include=["object"]).columns:

        df[column] = (
            df[column]
            .astype(str)
            .str.strip()
        )

    # ---------------------------------------------------------
    # Convert target
    # ---------------------------------------------------------

    if TARGET_COLUMN in df.columns:

        if df[TARGET_COLUMN].dtype == "object":

            target_mapping = {
                "Late": 1,
                "Delayed": 1,
                "On-Time": 0,
                "On Time": 0,
                "OnTime": 0,
                "0": 0,
                "1": 1
            }

            df[TARGET_COLUMN] = (
                df[TARGET_COLUMN]
                .map(target_mapping)
            )

        df[TARGET_COLUMN] = pd.to_numeric(
            df[TARGET_COLUMN],
            errors="coerce"
        )

    # ---------------------------------------------------------
    # Remove rows where target is missing
    # ---------------------------------------------------------

    df = df.dropna(subset=[TARGET_COLUMN])

    return df


def create_features(df):
    """
    Create additional business features.
    """

    df = df.copy()

    # ---------------------------------------------------------
    # Temperature category
    # ---------------------------------------------------------

    if "Temperature" in df.columns:

        df["Temperature_Risk"] = pd.cut(
            df["Temperature"],
            bins=[-np.inf, 10, 25, 35, np.inf],
            labels=[
                "Low",
                "Normal",
                "High",
                "Extreme"
            ]
        )

    # ---------------------------------------------------------
    # Humidity category
    # ---------------------------------------------------------

    if "Humidity" in df.columns:

        df["Humidity_Risk"] = pd.cut(
            df["Humidity"],
            bins=[-np.inf, 30, 60, 80, np.inf],
            labels=[
                "Low",
                "Normal",
                "High",
                "Very High"
            ]
        )

    # ---------------------------------------------------------
    # Waiting time category
    # ---------------------------------------------------------

    if "Waiting_Time" in df.columns:

        df["Waiting_Risk"] = pd.cut(
            df["Waiting_Time"],
            bins=[-np.inf, 20, 40, 60, np.inf],
            labels=[
                "Low",
                "Medium",
                "High",
                "Critical"
            ]
        )

    # ---------------------------------------------------------
    # Inventory risk
    # ---------------------------------------------------------

    if "Inventory_Level" in df.columns:

        df["Inventory_Risk"] = pd.cut(
            df["Inventory_Level"],
            bins=[-np.inf, 250, 500, 750, np.inf],
            labels=[
                "Low",
                "Medium",
                "High",
                "Very High"
            ]
        )

    return df


def get_model_data(df):
    """
    Separate features and target.

    IMPORTANT:
    Shipment_Status and Traffic_Status are excluded
    from ML because the dataset's delay label is
    derived from these fields.
    """

    X = df.drop(
        columns=[TARGET_COLUMN],
        errors="ignore"
    )

    y = df[TARGET_COLUMN]

    # ---------------------------------------------------------
    # Remove leakage columns
    # ---------------------------------------------------------

    leakage_columns = [
        "Shipment_Status",
        "Traffic_Status"
    ]

    X = X.drop(
        columns=[
            column
            for column in leakage_columns
            if column in X.columns
        ],
        errors="ignore"
    )

    # Asset ID behaves like an identifier rather than
    # a meaningful continuous measurement.
    #
    # We will keep it as categorical information if present.

    return X, y